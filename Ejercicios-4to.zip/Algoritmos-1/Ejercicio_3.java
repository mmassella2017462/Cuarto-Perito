import java.io.*;
import java.util.Scanner;
public class Ejercicio_3{
	public static void main(String[] args){
		Scanner datos = new Scanner(System.in);

		System.out.println( "Beinvenido al programa");
		System.out.println( "Se le idicada donde debe agregar el valor que desa convertir");
		System.out.println( "1) Convertir ");
		System.out.println( "2) Salir ");

		int opciones1 = datos.nextInt();
		if (opciones1 == 1){
			System.out.println("Agrege solamente el valor en numeros");
			int cantidad = datos.nextInt();
			System.out.println("Su respuesta se mostrara enseguida");
			double resolucion = cantidad * 3.28;
			double respuesta = resolucion;
			System.out.println("El valor en pies es" + respuesta);

		}

        else if (opciones1 == 2){
        	System.out.println("Gracias vuelva pronto");
        }


	}
}