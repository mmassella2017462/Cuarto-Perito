public class Ejercicio_1{
	public static void main(String[] args) {
		System.out.println("Hello");

		String name = "Usuario";
		System.out.println(name);

		//los datos a utilizarse son un ejemplo de comparacion de numeros

		int valor = 7;
		int valor2 = 2;
		Math.max(valor,valor2);
		System.out.println (Math.max(valor,valor2));

		System.out.println("Valor Mayor de la comparacion");



		
	

		String result = "2,7";
		System.out.println("El orden de menor a mayor es");
		System.out.println(result);
	}
		

}