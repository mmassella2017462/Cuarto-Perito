import java.io.*;
import java.util.Scanner;
public class Ejercicio_2{
	public static void main( String arg[]){
	Scanner datos = new Scanner(System.in);

	System.out.println( "le damos la bienvenida al programa de perimetro y area de un triangulo rectangulo" );
	System.out.println( "opciones" );
	System.out.println( "1) perimetro" );
    System.out.println( "2) area" );
    System.out.println( "3) salir" );
    
    int opciones1 = datos.nextInt();
    if (opciones1 == 1) {
    	System.out.println( "ingrese los datos en b base y en h altura" );
    	System.out.println( "designada para la variable b");
    	int b = datos.nextInt();
    	System.out.println( "designada para la variable h" );
    	int h = datos.nextInt();
    	int base = b * b;
    	int altura = h * h;
    	int c = base + altura;
    	double costado = Math.sqrt(c);
    	double perimetro = b + h + costado;

    	
    	
    		double resultado = perimetro;
    		System.out.println( "su perimetro es" + resultado );

    }
    
    else if( opciones1 == 2) {
    	System.out.println( " bienvenido al apartado del calculo de area");
    	System.out.println( "ingresa los datos y espera gracias...");
    	System.out.println( "ingresa el valor de B");
    	int b = datos.nextInt();
    	System.out.println( "ingresa el valor de H");
    	int h = datos.nextInt();
    	int calculo = (b*h)/2;
    	double resultado = calculo;
    	System.out.println( "su area es" + resultado);

    }


     else if ( opciones1 == 3) {
     	System.out.println( "Gracias por usar nuetro programa");
     }

}
	}