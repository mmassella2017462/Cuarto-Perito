import java.io.*;
import java.util.Scanner;
public class Ejercicio_5{
	public static void main(String[] args){
		Scanner datos = new Scanner(System.in);
		System.out.println("Bienvenido, esperamos que te sea util nuestro programa");
		System.out.println("Opciones");
		System.out.println("1) Sumar");
		System.out.println("2) Restar");
		System.out.println("3) Multiplicar");
		System.out.println("4) Dividir");
		int opcion1 = datos.nextInt();
		if (opcion1== 1){
			System.out.println("Ingrese las cantidades");
			System.out.println("El valor numero 1");
			int valor1 = datos.nextInt();
			System.out.println("El valor numero 2");
			int valor2 = datos.nextInt();
			int operado= valor1 + valor2;
			int resultado = operado; 
			System.out.println("el valor obtenido es " + resultado);

		}
	    
	    else if (opcion1== 2){
	    	System.out.println("Ingrese los valores que desea operar");
	    	System.out.println("la primera cantidad");
	    	int rest1 = datos.nextInt();
	    	System.out.println("ingrese el valor a quitar");
	    	int rest2 = datos.nextInt();
	    	int valor = rest1 - rest2;
	    	int residuo= valor;
	    	System.out.println("El resultado es " + residuo);


	    }
         
        else if (opcion1 == 3){
        	System.out.println("Este es el apartado de multiplicacion");
        	System.out.println("Ingrese su primer factor");
        	int multi1 = datos.nextInt();
        	System.out.println("Ingrese su multiplicador");
        	int multi2 = datos.nextInt();
        	int proceso=multi1 * multi2;
        	int residus= proceso;
        	System.out.println("Lo que se obtuvo es " + residus);

        } 
	   
	    else if (opcion1 == 4){
	    	System.out.println("Parte de la division");
	    	System.out.println("ingresa el dividendo");
	    	int dividendo = datos.nextInt();
	    	System.out.println("ingrese el divisor");
	    	int divisor =datos.nextInt();
	    	int pross = dividendo/ divisor;
	    	int result = pross;
	    	System.out.println("el residuo obtenido es " + result);

	    }
	
	}
} 