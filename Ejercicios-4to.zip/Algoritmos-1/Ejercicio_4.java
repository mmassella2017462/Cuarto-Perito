import java.io.*;
import java.util.Scanner;
public class Ejercicio_4{
	public static void main(String[] args){
		Scanner datos = new Scanner(System.in);
		System.out.println("Bienvenido");
		System.out.println("El programa realizara una conversion de kilometros por hora a metros por segundos");
		System.out.println("Opciones");
		System.out.println("1) Calcular");
		System.out.println("2) Salir");

		int opciones1 = datos.nextInt();
		if(opciones1 == 1) {
			System.out.println("Ingrese el valor que desea convertir");
			int convertir = datos.nextInt();
			int operado = (convertir*1000)/3600;
			int resultado = operado;
			System.out.println("La velocidad es de" + resultado + "metros por segundo");

		}
	    
	    else if (opciones1 ==2) {
	    	System.out.println( "Hasta la proxima");
	    }

	}
}