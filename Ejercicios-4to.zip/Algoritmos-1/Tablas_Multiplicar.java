import java.io.*;
import java.util.Scanner;
public class Tablas_Multiplicar {
	public static void main(String[] args){
		Scanner datos = new Scanner(System.in);
	System.out.println("-/-/-/-BIENVENIDO-/-/-/-");
	System.out.println("Las siguientes con las opciones para elegir");
	System.out.println(" 1) Mostrar una tabla especifica");
	System.out.println( "2) Cantidad de tablas de multiplicar");
	System.out.println( "3) SALIR");

	int opciones1 = datos.nextInt();
	if (opciones1 == 1){
		System.out.println("Ingrese el valor de la tabla que desea ver");
		int num_table = datos.nextInt();
		System.out.println("Ingrese el limite de multiplos para mostrar");
		int limit= datos.nextInt();
		for (int a = 1; a<= limit; a++){
			int muestra= num_table * a;
			System.out.println(+num_table+ "*" +a+ "=" + muestra);
		}
	}
	
     else if (opciones1== 2){
     	System.out.println("Ingrese el valor con el que se iniciara");
     	int b= datos.nextInt();
     	System.out.println("Ingrese el valor final");
     	int c = datos.nextInt();
     	for (int x= b; x<= c; x++){
     		System.out.println("Tabla de" + x);
     		for (int z = 1; z<= 9; z++){
     			System.out.println(x+ "*" +z+ "=" + (x*z));
     		}
     	}
     }

    else if (opciones1 == 3){
    	System.out.println("Gracias por usar nuestro programa");
    }
	}
	
}